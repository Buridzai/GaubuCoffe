let items=[
    {
        id: 1,
        name: "Pork Sandwich",
        image: require("@/assets/food_menu/single_food_1.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      },
      {
        id: 2,
        name: "Roasted Marrow",
        image: require("@/assets/food_menu/single_food_2.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      },
      {
        id: 3,
        name: "Summer Cooking",
        image: require("@/assets/food_menu/single_food_3.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      },
      {
        id: 4,
        name: "Easter Delight",
        image: require("@/assets/food_menu/single_food_4.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      },
      {
        id: 5,
        name: "Tiener Schnitze",
        image: require("@/assets/food_menu/single_food_5.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      },
      {
        id: 6,
        name: "Chicken Roast",
        image: require("@/assets/food_menu/single_food_6.png"),
        description: "They are wherein heaven seed hath nothing",
        price: 40,
        quality:1
      }
]
export default items