<template>
  <div>
    <p>Đây là trang thực đơn</p>
  </div>
</template>

<script>
export default {
    name:'ComThucDon'
}
</script>

<style>

</style>