<template>
  <div>
    <p>Đây là tang tin tức</p>
  </div>
</template>

<script>
export default {
    name:'ComTinTuc'
}
</script>

<style>

</style>