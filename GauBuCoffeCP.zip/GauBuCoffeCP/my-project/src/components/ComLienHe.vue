<template>
  <div>
    <p>Đây là trang liên hệ</p>
  </div>
</template>

<script>
export default {
    name:'ComLienHe'
}
</script>

<style>

</style>