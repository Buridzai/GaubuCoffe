<template>
  <div>
    <p>Đây là trang giới thiệu</p>
  </div>
</template>

<script>
export default {
    name:'ComGioiTh'
}
</script>

<style>

</style>